<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tiles_packed" tilewidth="18" tileheight="18" tilecount="180" columns="20">
 <image source="/tiles_packed.png" width="360" height="162"/>
</tileset>
